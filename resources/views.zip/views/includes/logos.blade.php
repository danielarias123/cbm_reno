<section id = 'logos-section'>
	<div class = 'container'>
		<div class = 'row'>
			<div class = 'col-sm-3 col-xs-6'>
				<img src="/images/trustedpros-logo-black.png" class = "img-responsive logo-image trustedpros-logo">
			</div>
			<div class = 'col-sm-3 col-xs-6'>
				<img src="/images/homestars-logo-black.png" class = "img-responsive logo-image">
			</div>
			<div class = 'col-sm-3 col-xs-6'>
				<img src="/images/houzz-logo-black.png" class = "img-responsive logo-image">
			</div>
			<div class = 'col-sm-3 col-xs-6'>
				<img src="/images/n49-logo-black.png" class = "img-responsive logo-image n49-logo">
			</div>
		</div>
	</div>
</section>
