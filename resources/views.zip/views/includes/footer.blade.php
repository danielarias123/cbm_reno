<section id="site-footer">
	<div class = "footer-container">
		<div class = "row">
			<ul id = "footer-navbar">
				<a href = "/"><li>Home</li></a>
				<a href = "/ourservices"><li>Our Services</li></a>
				<a href = "/projects"><li>Projects</li></a>
				<a href = "/ourstory"><li>Our Story</li></a>
				<a href = "/testimonials"><li>Testimonials</li></a>
				<a href = "/contact-us"><li>Contact Us</li></a>
			</ul>
			<div class="mixpanel-logo">
				<a href="https://mixpanel.com/f/partner" rel="nofollow"><img src="//cdn.mxpnl.com/site_media/images/partner/badge_light.png" alt="Mobile Analytics" /></a>
			</div>
		</div>
		<div class = 'copyright-text'>&copy; Copyright 2015 CBM Renovations. All Rights Reserved.</div>
	</div>
</section>